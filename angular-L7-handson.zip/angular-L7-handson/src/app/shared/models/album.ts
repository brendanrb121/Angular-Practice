export class Album {
    id: number;
    title: string;
    yearReleased: number;
}
